const app = {
    yummyID: 'dfbe7dff',
    yummyKey: '75b55bb1a2c32ecbfa9c0db685d25f57',
    recipeList: [],
    title: ['When Life Gives You <i class="far fa-lemon"></i>s',
            `What's in your fridge?`, 
            `I'm feeling lucky`,
            `Get Yummy!`,
            `Feed Me!`,
            `I'm hungry`]
};
//------------
// Firebase
//------------
app.config = () => {
    // Initialize Firebase
    var config = {
        apiKey: "AIzaSyBRZp0fU7NBqDmu05_CT2o8SPIaKdKAWzQ",
        authDomain: "project-3-2200f.firebaseapp.com",
        databaseURL: "https://project-3-2200f.firebaseio.com",
        projectId: "project-3-2200f",
        storageBucket: "project-3-2200f.appspot.com",
        messagingSenderId: "577963231730"
    };
    firebase.initializeApp(config);
    //getting reference to firebase database
    app.database = firebase.database();
    app.saveRecipe = app.database.ref(`/saveRecipe`)
};

function  googleLogin() {
    const provider = new firebase.auth.GoogleAuthProvider();
    firebase.auth().signInWithPopup(provider)
        .then(result => {
            const user = result.user;
            const loginDiv = $('#login');
            loginDiv.empty();
            loginDiv.append(`
            <p> Hello ${user.displayName} </p>
            <button onclick="googleLogout()">Logout</button>
            `);
        })
        .catch(console.log);
}

function  googleLogout() {
    firebase.auth().signOut();
    const loginDiv = $('#login');
    loginDiv.empty();
    loginDiv.append(`
            <button onclick="googleLogin()">Logout</button>
            `);

}

//empty array to hold all the recipe IDs
app.recipeIDList = [];

//----------------------------------------------------
// Display Recipes with data returned from Yummly API
//----------------------------------------------------
app.displayRecipe = (food) =>{
    $('.recipe').empty();
    app.recipeIDList = [];

    for (let i = 0; i < food.length; i++) {
        const recipeName = food[i].recipeName;
        const recipeImg = food[i].imageUrlsBySize['90'];
        const ingredients = food[i].ingredients;
        const recipeID = food[i].id;
        //add all the recipe IDs to the recipeIDList
        app.recipeIDList.push(recipeID);
        //empty string for ingredient List
        let ingredientList = '';

        //loop through ingredients to add each ingredients for each recipe to their own list
        food[i].ingredients.forEach((ingredient) => {
            ingredientList = ingredientList + `<li>${ingredient}</li>`
        });

        $('.recipe').append(
            `<li id ="${i}" class='flex recipeContainer'>
                <div class='imgContainer'>
                    <img src='${recipeImg}' class='recipeImg' alt="${recipeName} image">
                    <div class='overlay overlay-down'>
                        <div class='text'>${recipeName}</div>
                    </div>
                </div>
            </li>`
        );
    };
    // <div>
    //     <ul class='ingredients'>
    //         ${ingredientList}
    //     </ul>
    // </div>
    
};

//-----------------------------------
// Display only one specific recipe
//-----------------------------------
app.displayDetailedRecipe = (recipeDetails) => {
    $('#clickedRecipe').empty();
    $('#clickedRecipe').removeClass('hidden');
    const clickedRecipe = $('#clickedRecipe');
    const title = recipeDetails.name;
    const img = recipeDetails.images[0].hostedLargeUrl;
    const source = recipeDetails.source.sourceRecipeUrl;
    const totalTime = recipeDetails.totalTime;
    const numberOfServings = recipeDetails.numberOfServings;
    const ingredients = recipeDetails.ingredientLines;
    let ingredientList = '';

    ingredients.forEach(ingredient => {
        ingredientList = ingredientList + `<li>${ingredient}</li>`
    });

    clickedRecipe.append(`
        <button id="xButton" ><i class="fas fa-times"></i></button>
        <div>
            <h2>${title}</h2>
            <img src="${img}" alt="${title} image">
            <p> Preptime: ${totalTime} </p>
            <p> Number of Servings: ${numberOfServings}</p>
            <ul class='ingredients'>
                ${ingredientList}
            </ul>
        </div>
        <p> Open the recipe book </p>
        <a href="${source}" target="_blank"><i class="fas fa-book"></i></a>
    `);
    //include an x button to go back to search
}

//----------------------------------------
// API call to yummly for list of recipes
//----------------------------------------
app.getYummy = (arr) =>{
    $.ajax({
        url:`http://api.yummly.com/v1/api/recipes?_app_id=dfbe7dff&_app_key=75b55bb1a2c32ecbfa9c0db685d25f57`,
        method:'GET',
        dataType:'jsonp',
        data:{
            requirePictures: true,
            allowedIngredient: arr,
        }
    }).then((res) => {
        const recipes = res.matches;
        if(recipes.length === 0){
            //display no matches message
            app.noResult();
            $('.recipe').empty();
        }else{
            //display recipes
            app.displayRecipe(recipes);
            app.hideNoResult();
        }
    });
};


//----------------------------------------
// API call to yummly for specific recipe
//----------------------------------------
app.getOneRecipe = (recipeID) => {

    $.ajax({
        url: `http://api.yummly.com/v1/api/recipe/${recipeID}?_app_id=dfbe7dff&&_app_key=75b55bb1a2c32ecbfa9c0db685d25f57`,
        method: 'GET',
        dataType: 'jsonp',
        data: {
            requirePictures: true,
        }
    }).then((res) => {
        //display clicked recipe with more info
        app.displayDetailedRecipe(res);

        //recently viewed
        //firebase Save this data

    });
};

//--------------------------------------------
// x button to remove detailed recipe display
//--------------------------------------------
app.removeDetailedRecipeDisplay = () => {
    const clickedRecipe = $('#clickedRecipe');
    clickedRecipe.on('click', '#xButton', function () {
        clickedRecipe.empty();
        clickedRecipe.addClass('hidden');
    });
};

//----------------------------
// Remove ingredient from list
//----------------------------
app.removeIngredientFromList = (removeIngredient) => {
    //find index of ingredient to remove
    let indexToRemove = app.recipeList.indexOf(removeIngredient);
    //if ingredient is found then remove it from array
    if(indexToRemove > -1){
        app.recipeList.splice(indexToRemove, 1);
    }
    //make new api call to Yummly
    if (app.recipeList === undefined || app.recipeList.length == 0) {
        // clear recipes if there are no ingredients
        $('.recipe').empty();
        app.noResult();
    }else{
        //make api call if there are ingredients
        app.getYummy(app.recipeList);
        app.hideNoResult();
    }
};

//-----------------
// Add ingredients
//-----------------
app.addIngredient = (foodItem) => {
    const removalLink = `<a href='#' class="float-right"><i class="fas fa-times"></i></a>`
    const ingredientToAdd = `<li> ${foodItem} ${removalLink} </li>`
    $('.ingredientsList').append(ingredientToAdd);
};

//---------------------
// Remove ingredients
//---------------------
app.removeIngredient = () => {
    $('ul').on('click', 'a', function () {
        //removing entire li
        const ingredientToRemove = $(this).parent();
        ingredientToRemove.remove();
        //get text of ingredient
//**********************************************************************************************        
//for some reason there's a space in front of ingredientsToRemoveName
//**********************************************************************************************
        const ingredientToRemoveName = ingredientToRemove.text().replace(/\s+/g, " ").trim();
        let finalList = app.removeIngredientFromList(ingredientToRemoveName);
    });
};

//------------------------
// Remove no results text
//------------------------
app.hideNoResult = () => {
    const noResults = $("#noResults");
    noResults.addClass("hidden");
};

//-----------------------
// Show no results text
//-----------------------
app.noResult = () => {
    if(app.recipeList.length > 0){
        const noResults = $("#noResults");
        noResults.removeClass("hidden");
    };
};

//-----------------------
// Push data to firebase
//-----------------------
app.pushDataToFirebase = () => {
    const recipeInfo = {
    };
    app.saveRecipe.push(recipeInfo);
}

//-----------------------------------------
// Listen for when user clicks on a recipe 
//-----------------------------------------
app.recipeClicked = () => {
        $('.recipe').on('click', '.recipeContainer', function (e) {
            // need to find which recipe number is clicked
            let numOfRecipe = this.id;
            //app.recipeIDList[recipe number clicked]
            let recipeID = app.recipeIDList[numOfRecipe];
            //pass app.recipeIDList[num] to app.getOneRecipe();
            app.getOneRecipe(recipeID);
    });
};

//-----------------
// Get User Input
//-----------------
app.getIngredient = () => {
    $('.ingredients').on('submit', function (e) {
        e.preventDefault();
        const ingredient = $('input[type=text]').val();
        if ($(ingredient.length > 0)) {
            $('header').fadeOut();
            //pineapple images roll out
            const pineappleImg = $('.pineapple');
            for(let i=0; i<pineappleImg.length; i++){
                pineappleImg[i].classList.remove('rollIn');
                pineappleImg[i].classList.add('animated');
                pineappleImg[i].classList.add('rollOut');
            }
            $('.pineapple-container').delay(800).remove();


            app.addIngredient(ingredient);
            app.recipeList.push(`${ingredient}`);
            app.getYummy(app.recipeList);
        };
        //reset input field 
        $(this)[0].reset();
    });
};

//--------------
// Random Title
//--------------

// Random Number
app.randomNum = (arr) => {
    return Math.floor(Math.random() * arr);
};
// Random Title
app.randomTitle = () => {
    const title = $('#title');
    const randomNum = app.randomNum(app.title.length);
    title.append(app.title[randomNum]);
};
//---------------------
// Starting animations
//---------------------
//dat fade tho
app.fade = (tag) => {
    $(`${tag}`).delay(1000).animate({ "opacity": "1" }, 700);
};

//closing the sidebar

app.closeSidebar = () =>{
    $("#MainMenu").css("-webkit-clip-path", "polygon(0 0,0% 0,100% 100%,0% 100%)");
    function hideMenu() {
        $("#MainMenu").css("left", "-300px");
        $("#MenuIcon").animate({ right: '50' }, 300);
    }
    setTimeout(hideMenu, 300);

    function originalLayout() {
        $("#MainMenu").css("-webkit-clip-path", "polygon(0 0,100% 0,0% 100%,0% 100%)");
    }
    setTimeout(originalLayout, 600);
}
//click of menu button
app.menuClick = () => {

        $("#MenuIcon").click(function () {
            $("#MainMenu").css("left", "0px");
            function showMenu() {
                $("#MainMenu").css("-webkit-clip-path", "polygon(0 0,100% 0,100% 100%,0% 100%)");
                $("#MenuIcon").animate({ right: '-100' }, 300);
            }
            setTimeout(showMenu, 100);
            $('input[type=text]').focus();
        });

        $("#close").click(function () {
            app.closeSidebar();
        });

        $(".generatedRecipes").click(function () {
            app.closeSidebar();
        });
};

//--------------
//init function
//--------------
app.init = () =>{
    app.canvasSize;
    //fade in header
    app.fade('header');
    //on click of Menu
    app.menuClick();
    //random title
    app.randomTitle();
    //listen for when ingredients are submitted and gets recipes from Yummly
    app.getIngredient();
    //remove ingredients once x button is clicked
    app.removeIngredient();
    //listen for clicks on specific recipes 
    app.recipeClicked();
    app.removeDetailedRecipeDisplay();
};

//---------------
//document.ready
//---------------
$(function () {
    app.init();
    //firebase
    app.config();

});